// Write a program as per following details
// Create one base class HOTEL with following data members
// Hotel_name,
// Hotel_type i.e(Three star,five star)
// City
// Hotel_rate i.e(2000,3000,5000)
// Create one base class FLIGHT with following data members
// Flight_no
// Source city
// Destination city
// Seat no
// Create one sub class PASSENGER derived from HOTEL and FLIGHT with following
// data members Name, Age, city
// Write appropriate member functions in each class and display all information in main