// 6. Write a program as per following details
// Create one base class PERSON with following data members
// Name, College name
// Create one sub class STUDENT derived from PERSON with following data members
// Student_id , Marks of five subject, percentage Member function: showResult( )-
// Calculate total,percentage and finding class(Dist,First,second,pass)
// Create one sub class EMPLOYEE derived from PERSON with following data members
// Emp_id, qualification , basic salary
// Member function to calculate Net salary and print Net salary
// DA=189% of Basic salary
// HRA=10% of Basic salary
// TA=500
// Income tax=5 % of basic salary, if basic salary >50000
// Income tax=0, if Basic salary <=50000
// Netsalary=(basicsalary+da+hra+ta) - income tax
// Write appropriate setter function in each class and display detail of student and
// employee in main.